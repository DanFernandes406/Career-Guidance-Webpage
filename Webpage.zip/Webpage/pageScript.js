const form = document.getElementById('form1');
	
	form.addEventListener('submit', function(e) {
    const result = document.getElementById('result');
		const formData = new FormData(form);
		e.preventDefault();
	
		const object = Object.fromEntries(formData);
		const json = JSON.stringify(object);
    result.innerHTML = ""
		result.innerHTML = "Please wait..."
	
		fetch('https://api.web3forms.com/submit', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Accept': 'application/json'
				},
				body: json
			})
			.then(async (response) => {
				let json = await response.json();
				if (response.status == 200) {
					result.innerHTML = json.message;
				} else {
					console.log(response);
					result.innerHTML = json.message;
				}
			})
			.catch(error => {
				console.log(error);
				result.innerHTML = "Something went wrong!";
			})
			.then(function() {
				form.reset();
				setTimeout(() => {
					result.style.display = "none";
				}, 3000);
			});
	});
  function scrollToSection(sectionId) {
    var usecaseElement = document.getElementById('dec');
    usecaseElement.scrollIntoView({ behavior: "smooth"});
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  }
            let pageN = '4';
            let optionsContainer ='';
              function showOriginalCard(cardId) {
                const card = document.getElementById(cardId);
                const optionsContainer = document.getElementById('optionsContainer');
                
                card.classList.remove('hidden');
                optionsContainer.style.display = 'none';
                document.getElementById('backButton').classList.add('hidden');
              }
        
              function showOptions(cardId) {
                var usecaseElement = document.getElementById('dec');
                usecaseElement.scrollIntoView({ behavior: "smooth"});
                pageN = 2
                const dis = document.getElementById('dis');
                dis.style.paddingBottom = '50px'
                console.log(dis)
                const card = document.getElementById(cardId);
                if (cardId == 'pcmCard'){
                    optionsContainer = document.getElementById('optionsContainerPCM');
                } else if(cardId == 'pcbCard'){
                    optionsContainer = document.getElementById('optionsContainerPCB');
                } else if(cardId == 'pcmbCard'){
                    optionsContainer = document.getElementById('optionsContainerPCMB');
                }
                else if(cardId == 'artsCard'){
                    optionsContainer = document.getElementById('optionsContainerArts');
                }else if(cardId == 'commerceCard'){
                    optionsContainer = document.getElementById('optionsContainerCommerce');
                }else if(cardId == 'nonCoreCard'){
                    optionsContainer = document.getElementById('optionsContainerNonCore');
                }
                const optionsContainerScience = document.getElementById('optionsContainerPCM');
                const pcbCard = document.getElementById('pcbCard')
                const pcmCard = document.getElementById('pcmCard')
                const pcmbCard = document.getElementById('pcmbCard')
                const subSubjectCards = ['pcmCard', 'pcbCard', 'pcmbCard'];
                for (const cardId1 of subSubjectCards) {
                    const card1 = document.getElementById(cardId1);
                    console.log('h')
                  if (cardId!= cardId1) {
                    card1.classList.add('hidden');
                  }
                }
                card.classList.add('hidden');
                optionsContainer.style.display = 'block';
                document.getElementById('backButton').classList.remove('hidden');
              }
        
              function hideOptions() {
                const optionsContainerScience = document.getElementById('optionsContainerScience');
                if (optionsContainer!= ''){
                optionsContainer.style.display = 'none';
                const dis = document.getElementById('dis');
                dis.style.paddingBottom = '50px'
                console.log(dis)
                }
                const optionsContainerCommerce = document.getElementById('optionsContainerCommerce');
                optionsContainerCommerce.style.display = 'none';
                const optionsContainerArts = document.getElementById('optionsContainerArts');
                optionsContainerArts.style.display = 'none';
                const optionsContainerNonCore = document.getElementById('optionsContainerNonCore');
                optionsContainerNonCore.style.display = 'none';
                const scienceCard = document.getElementById('scienceCard');
                const nonCoreCard = document.getElementById('nonCoreCard');
                const artsCard = document.getElementById('artsCard');
                const commerceCard = document.getElementById('commerceCard');
                const pcmCard = document.getElementById('pcmCard');
                const pcbCard = document.getElementById('pcbCard');
                const pcmbCard = document.getElementById('pcmbCard');
                
                const backButton = document.getElementById('backButton');
                console.log(pageN)
                if (pageN == 1){
                console.log('ji')
                nonCoreCard.classList.remove('hidden');
                artsCard.classList.remove('hidden');
                scienceCard.classList.remove('hidden');
                commerceCard.classList.remove('hidden');
                pcmCard.classList.add('hidden');
                pcbCard.classList.add('hidden');
                pcmbCard.classList.add('hidden');
                backButton.style.opacity = -1;
                pageN = 0;
                const dis = document.getElementById('dis');
                dis.style.paddingBottom = '50px'
                console.log(dis)
                } else if(pageN == 2){
                pcmCard.classList.remove('hidden');
                pcbCard.classList.remove('hidden');
                pcmbCard.classList.remove('hidden');
                pageN = 1;
                }
              }
        
              function showScienceCard() {
                pageN = 1
                var usecaseElement = document.getElementById('dec');
                usecaseElement.scrollIntoView({ behavior: "smooth"});
                const scienceCard = document.getElementById('scienceCard');
                const nonCoreCard = document.getElementById('nonCoreCard');
                const artsCard = document.getElementById('artsCard');
                const commerceCard = document.getElementById('commerceCard');
                const pcmCard = document.getElementById('pcmCard');
                const pcbCard = document.getElementById('pcbCard');
                const pcmbCard = document.getElementById('pcmbCard');
                const backButton = document.getElementById('backButton');
                console.log(backButton)
                const dis = document.getElementById('dis');
                dis.style.paddingBottom = '50px'
                console.log(dis)
                backButton.style.opacity = 1;
                nonCoreCard.classList.add('hidden');
                artsCard.classList.add('hidden');
                scienceCard.classList.add('hidden');
                commerceCard.classList.add('hidden');
                pcmCard.classList.remove('hidden');
                pcbCard.classList.remove('hidden');
                pcmbCard.classList.remove('hidden');
              
                
              }
              function showCommerceCard() {
                pageN = 1
                var usecaseElement = document.getElementById('dec');
                usecaseElement.scrollIntoView({ behavior: "smooth"});
                optionsContainer = document.getElementById('optionsContainerCommerce');
                const scienceCard = document.getElementById('scienceCard');
                const nonCoreCard = document.getElementById('nonCoreCard');
                const artsCard = document.getElementById('artsCard');
                const commerceCard = document.getElementById('commerceCard');
                const pcmCard = document.getElementById('pcmCard');
                const pcbCard = document.getElementById('pcbCard');
                const pcmbCard = document.getElementById('pcmbCard');
                const optionsContainerCommerce = document.getElementById('optionsContainerCommerce');
                const backButton = document.getElementById('backButton');
                backButton.style.opacity = 1;
                nonCoreCard.classList.add('hidden');
                artsCard.classList.add('hidden');
                scienceCard.classList.add('hidden');
                commerceCard.classList.add('hidden');
                optionsContainerCommerce.style.display = 'block';
              

              }
              function showArtsCard() {
                pageN = 1
                var usecaseElement = document.getElementById('dec');
                usecaseElement.scrollIntoView({ behavior: "smooth"});
                optionsContainer = document.getElementById('optionsContainerArts');
                const scienceCard = document.getElementById('scienceCard');
                const nonCoreCard = document.getElementById('nonCoreCard');
                const artsCard = document.getElementById('artsCard');
                const commerceCard = document.getElementById('commerceCard');
                const optionsContainerArts = document.getElementById('optionsContainerArts');
                const backButton = document.getElementById('backButton');
                backButton.style.opacity = 1;
                nonCoreCard.classList.add('hidden');
                artsCard.classList.add('hidden');
                scienceCard.classList.add('hidden');
                commerceCard.classList.add('hidden');
                optionsContainerArts.style.display = 'block';
              
         
              }
              function showNonCoreCard() {
                pageN = 1
                var usecaseElement = document.getElementById('dec');
                usecaseElement.scrollIntoView({ behavior: "smooth"});
                optionsContainer = document.getElementById('optionsContainerNonCore');
                const scienceCard = document.getElementById('scienceCard');
                const nonCoreCard = document.getElementById('nonCoreCard');
                const artsCard = document.getElementById('artsCard');
                const commerceCard = document.getElementById('commerceCard');
                const optionsContainerNonCore = document.getElementById('optionsContainerNonCore');
                const backButton = document.getElementById('backButton');
                backButton.style.opacity = 1;
                nonCoreCard.classList.add('hidden');
                artsCard.classList.add('hidden');
                scienceCard.classList.add('hidden');
                commerceCard.classList.add('hidden');
                optionsContainerNonCore.style.display = 'block';
              
                
              }
              var jsonData = {
                
  "doctor": {
    "title": "Doctor Profession After 12th FAQs",
    "content": "Here are some of the frequently asked questions",
    "questions": [
      {
        "question": "What are the steps to become a doctor after 12th in India?",
        "answer": "To become a doctor in India, you typically need to pursue an undergraduate medical degree (MBBS) after completing the 12th standard with Physics, Chemistry, and Biology. After MBBS, further specialization can be pursued through postgraduate degrees like MD or MS."
      },
      {
        "question": "What entrance exams are required for medical admissions after 12th?",
        "answer": "Common entrance exams for medical admissions in India include NEET (National Eligibility Cum Entrance Test) for MBBS and BDS courses. Some states may have their own entrance exams for admission to medical colleges."
      },
      {
        "question": "Are there alternative medical courses besides MBBS after 12th?",
        "answer": "Yes, there are alternative courses like Bachelor of Dental Surgery (BDS), Bachelor of Ayurvedic Medicine and Surgery (BAMS), Bachelor of Homeopathic Medicine and Surgery (BHMS), and Bachelor of Physiotherapy (BPT) that can be pursued after 12th."
      },
      {
        "question": "What is the duration of the MBBS course in India?",
        "answer": "The MBBS course in India typically has a duration of 5.5 years, including 4.5 years of academic study and 1 year of compulsory internship."
      },
      {
        "question": "How competitive is the admission process for medical courses?",
        "answer": "Medical admissions in India are highly competitive, especially for MBBS. Securing a good rank in the NEET exam is crucial for admission to reputable medical colleges."
      }
    ]
  },

            "engineering": {
                "title": "Engineering FAQ",
                "content": "Here are some of the frequently asked questions",
                "questions": [
                    {
                        "question": "What are the different branches of engineering offered in India?",
                        "answer": "India offers various engineering branches such as Civil, Mechanical, Electrical, Computer Science, Electronics and Communication, Chemical, Aerospace, and more. The choice depends on individual interests and career goals."
                    },
                    {
                        "question": "How do I choose the right engineering branch for my career goals?",
                        "answer": "Consider your interests, aptitude, and career aspirations. Research the scope, job opportunities, and industry demand for each branch. Seek guidance from career counselors and professionals in the field."
                    },
                    {
                        "question": "What is the duration of a typical engineering course in India?",
                        "answer": "The typical duration for a bachelor's degree in engineering (B.Tech) in India is four years. Some specialized programs may have a different duration."
                    },
                    {
                        "question": "How is the engineering curriculum structured in Indian universities?",
                        "answer": "The engineering curriculum usually includes a combination of core subjects, electives, practical sessions, and a final-year project. It aims to provide a comprehensive understanding of the chosen engineering discipline."
                    },
                    {
                        "question": "What is the eligibility criteria for admission to engineering colleges in India?",
                        "answer": "Eligibility criteria vary but generally include completing 10+2 with Physics, Chemistry, and Mathematics. Entrance exams like JEE Main, BITSAT, or state-specific exams are commonly required."
                    },
                    {
                        "question": "What entrance exams are commonly required for engineering admissions?",
                        "answer": "Common entrance exams include JEE Main (for NITs and IIITs), JEE Advanced (for IITs), BITSAT (for BITS Pilani), and state-specific exams like MHT CET, KEAM, etc."
                    },
                    {
                        "question": "Are there any scholarships available for engineering students in India?",
                        "answer": "Yes, various scholarships are available based on merit, financial need, and specific criteria. Government schemes, private organizations, and universities offer scholarships to eligible students."
                    },
                    {
                        "question": "What is the importance of accreditation for engineering colleges in India?",
                        "answer": "Accreditation ensures that the engineering program meets quality standards. It is essential for recognition, credibility, and eligibility for further studies or employment."
                    }
                ]
            },
                
                "doctor": {
                  "title": "Doctor Profession After 12th FAQs",
                  "content": "Here are some of the frequently asked questions",
                  "questions": [
                    {
                      "question": "What are the steps to become a doctor after 12th in India?",
                      "answer": "To become a doctor in India, you typically need to pursue an undergraduate medical degree (MBBS) after completing the 12th standard with Physics, Chemistry, and Biology. After MBBS, further specialization can be pursued through postgraduate degrees like MD or MS."
                    },
                    {
                      "question": "What entrance exams are required for medical admissions after 12th?",
                      "answer": "Common entrance exams for medical admissions in India include NEET (National Eligibility Cum Entrance Test) for MBBS and BDS courses. Some states may have their own entrance exams for admission to medical colleges."
                    },
                    {
                      "question": "Are there alternative medical courses besides MBBS after 12th?",
                      "answer": "Yes, there are alternative courses like Bachelor of Dental Surgery (BDS), Bachelor of Ayurvedic Medicine and Surgery (BAMS), Bachelor of Homeopathic Medicine and Surgery (BHMS), and Bachelor of Physiotherapy (BPT) that can be pursued after 12th."
                    },
                    {
                      "question": "What is the duration of the MBBS course in India?",
                      "answer": "The MBBS course in India typically has a duration of 5.5 years, including 4.5 years of academic study and 1 year of compulsory internship."
                    },
                    {
                      "question": "How competitive is the admission process for medical courses?",
                      "answer": "Medical admissions in India are highly competitive, especially for MBBS. Securing a good rank in the NEET exam is crucial for admission to reputable medical colleges."
                    }
                  ]
                },
              
                "architect": {
        "title": "Architect Profession FAQs",
        "content": "Here are some frequently asked questions about pursuing a career as an architect.",
        "questions": [
            {
                "question": "What is the role of an architect?",
                "answer": "Architects are creative professionals who design and plan buildings and other structures. They combine artistic vision with technical knowledge to create functional and aesthetically pleasing spaces."
            },
            {
                "question": "What qualifications are required to become an architect?",
                "answer": "To become an architect, one typically needs a Bachelor's degree in Architecture (B.Arch) which has a duration of 5 years. Additionally, obtaining a license is required to practice as a registered architect."
            },
            {
                "question": "What is the duration of the Bachelor of Architecture (B.Arch) course?",
                "answer": "The Bachelor of Architecture (B.Arch) course in India typically has a duration of 5 years."
            },
            {
                "question": "Are there any specific skills required for a career in architecture?",
                "answer": "Skills required for a career in architecture include creativity, strong drawing and design skills, spatial awareness, attention to detail, and the ability to work with clients and construction professionals."
            }
        ]
    },

    "army": {
        "title": "Army Service FAQs",
        "content": "Here are some of the frequently asked questions",
        "questions": [
            {
                "question": "What does a career in Army Service involve?",
                "answer": "A career in Army Service involves serving in the armed forces, protecting the country, and undertaking various roles such as combat, logistics, intelligence, and leadership."
            },
            {
                "question": "What is the eligibility criteria for joining the Army?",
                "answer": "Eligibility criteria vary based on the role but typically include completing high school education. Additional criteria may apply, including age limits, physical fitness, and educational qualifications."
            },
            {
                "question": "How long is the training duration for Army professionals?",
                "answer": "Training duration varies based on the specific role and branch of service. Army professionals undergo rigorous training to develop discipline, teamwork, and specialized skills."
            }
        ]
    },

    "scientist": {
        "title": "Scientist Profession FAQs",
        "content": "Here are some of the frequently asked questions",
        "questions": [
            {
                "question": "What do scientists do?",
                "answer": "Scientists conduct research and experiments to expand our understanding of the world. They explore various scientific disciplines, such as physics, chemistry, biology, and environmental science."
            },
            {
                "question": "What qualifications are required to become a scientist?",
                "answer": "To become a scientist, a minimum of a bachelor's degree in a relevant scientific field is required. Many scientists pursue advanced degrees (Master's or Ph.D.) for specialized research roles."
            },
            {
                "question": "How long does it take to become a scientist?",
                "answer": "The duration varies, with a minimum of 3-4 years for a bachelor's degree and additional 2-6 years for advanced degrees (Master's or Ph.D.) depending on the field of study."
            },
            {
                "question": "What is the role of scientists in addressing global challenges?",
                "answer": "Scientists play a crucial role in addressing global challenges by contributing to knowledge advancement, technological innovations, and the development of solutions to issues such as climate change, diseases, and more."
            }
        ]
    },
    "charteredAccountant": {
        "title": "Chartered Accountant (CA) FAQs",
        "content": "Here are some of the frequently asked questions",
        "questions": [
            {
                "question": "What does a Chartered Accountant do?",
                "answer": "Chartered Accountants (CAs) are highly skilled finance professionals responsible for managing financial reporting, taxation, auditing, and advisory services for businesses."
            },
            {
                "question": "What qualifications are required to become a Chartered Accountant?",
                "answer": "To become a Chartered Accountant, one needs to complete the CA course, which involves passing the CA Foundation, CA Intermediate, and CA Final examinations conducted by the Institute of Chartered Accountants of India (ICAI)."
            },
            {
                "question": "How long does it take to become a Chartered Accountant?",
                "answer": "The duration to become a Chartered Accountant varies but typically takes around 4-5 years, including the required practical training period."
            }
        ]
    },

    "businessAdministrator": {
        "title": "Business Administrator FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What is the role of a Business Administrator?",
                "answer": "Business Administrators are organizational leaders who oversee the day-to-day operations of a company or organization. They manage resources, implement policies, and make strategic decisions to optimize efficiency and achieve business goals."
            },
            {
                "question": "What qualifications are required to become a Business Administrator?",
                "answer": "Qualifications for becoming a Business Administrator may include a bachelor's degree in business administration, management, or a related field. Relevant work experience and skills in leadership and decision-making are also valuable."
            },
            {
                "question": "Are there specific areas of specialization for Business Administrators?",
                "answer": "Business Administrators may specialize in areas such as finance, human resources, marketing, operations, or strategic management, depending on their career goals and interests."
            }
        ]
    },

    "companySecretary": {
        "title": "Company Secretary FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What is the role of a Company Secretary?",
                "answer": "Company Secretaries play a vital role in corporate governance, ensuring compliance with legal and regulatory requirements. They serve as key advisers to the board, managing corporate governance procedures, maintaining statutory records, and facilitating communication between the company and regulatory authorities."
            },
            {
                "question": "What qualifications are required to become a Company Secretary?",
                "answer": "To become a Company Secretary, one needs to complete the Company Secretaryship course offered by the Institute of Company Secretaries of India (ICSI). The course includes three stages: Foundation, Executive, and Professional."
            },
            {
                "question": "What is the scope of Company Secretaries in the business world?",
                "answer": "Company Secretaries have a broad scope, contributing to legal compliance, corporate governance, and strategic decision-making. They often hold key positions in companies, serving as a bridge between the board and various stakeholders."
            }
        ]
    },

    "investmentBanking": {
        "title": "Investment Banking FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What is the role of an Investment Banker?",
                "answer": "Investment Bankers are finance professionals specializing in facilitating capital raising, mergers, acquisitions, and other financial transactions for corporations and governments."
            },
            {
                "question": "What qualifications are required to become an Investment Banker?",
                "answer": "Qualifications for becoming an Investment Banker may include a strong educational background in finance, economics, or a related field. Many professionals also pursue advanced degrees (Master's or MBA) and gain relevant work experience."
            },
            {
                "question": "How competitive is the field of Investment Banking?",
                "answer": "Investment Banking is highly competitive, and professionals often work in fast-paced environments. Strong analytical skills, financial acumen, and the ability to handle complex transactions are essential for success."
            }
        ]
    },

    "teacher": {
        "title": "Teacher FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What is the role of a Teacher?",
                "answer": "Teachers educate and guide students in various subjects and skills. They create lesson plans, assess student progress, and foster a positive learning environment."
            },
            {
                "question": "What qualifications are required to become a Teacher?",
                "answer": "To become a Teacher, one typically needs a Bachelor's degree in Education (B.Ed) or a degree in a specific subject along with a teaching certification. Additional requirements may vary based on the educational level being taught."
            },
            {
                "question": "How important is effective communication in teaching?",
                "answer": "Effective communication is crucial in teaching. Teachers need to convey information clearly, engage students, and create an environment that supports learning. Communication skills also help in building positive relationships with students and parents."
            }
        ]
    },

    "lawyer": {
        "title": "Lawyer FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What does a Lawyer do?",
                "answer": "Lawyers provide legal advice and representation to individuals and organizations. They may specialize in areas such as criminal law, civil law, corporate law, or family law."
            },
            {
                "question": "What qualifications are required to become a Lawyer?",
                "answer": "To become a Lawyer, one typically needs to complete a Bachelor of Laws (LL.B) or an integrated law program after completing 10+2. Following the undergraduate degree, aspiring lawyers often pursue internships and may take bar exams for licensure."
            },
            {
                "question": "How does specialization work in the field of law?",
                "answer": "Lawyers can specialize in specific areas of law based on their interests and career goals. Specializations may include criminal law, corporate law, intellectual property law, family law, and more."
            }
        ]
    },

    "journalist": {
        "title": "Journalist FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What does a Journalist do?",
                "answer": "Journalists gather and report news stories through various media channels, including print, broadcast, and online platforms. They conduct interviews, research topics, and present information in an unbiased and engaging manner."
            },
            {
                "question": "What qualifications are required to become a Journalist?",
                "answer": "Qualifications for becoming a Journalist may include a Bachelor's degree in Journalism, Mass Communication, or a related field. Practical experience through internships and a strong portfolio of work are also valuable."
            },
            {
                "question": "How important is objectivity in journalism?",
                "answer": "Objectivity is a key principle in journalism. Journalists strive to present information fairly, accurately, and without bias. Objectivity helps maintain the integrity of news reporting and ensures that the audience receives balanced and truthful information."
            }
        ]
    },

    "socialWork": {
        "title": "Social Work FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What does a Social Worker do?",
                "answer": "Social Workers help individuals and communities overcome challenges and improve well-being. They assess clients' needs, provide support and resources, and may work in areas such as healthcare, child welfare, or mental health."
            },
            {
                "question": "What qualifications are required to become a Social Worker?",
                "answer": "To become a Social Worker, one typically needs a Bachelor's or Master's degree in Social Work (BSW or MSW). Specializations may include clinical social work, school social work, or healthcare social work."
            },
            {
                "question": "How important is empathy in the field of social work?",
                "answer": "Empathy is crucial in social work. Social Workers need to understand and connect with the experiences of their clients, showing compassion and support. Empathy helps build trust and facilitates effective communication in the helping process."
            }
        ]
    },

    "politician": {
        "title": "Politician FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What does a Politician do?",
                "answer": "Politicians work in government, making decisions and representing the interests of the public. They may serve in various capacities, including local, state, or national levels. Politicians engage with constituents, develop policies, and participate in legislative processes."
            },
            {
                "question": "What qualifications are required to become a Politician?",
                "answer": "Qualifications for becoming a Politician vary, but generally, individuals need to be citizens, meet age requirements, and may need to win elections to hold public office. Strong leadership, communication, and knowledge of public issues are important."
            },
            {
                "question": "How can individuals get involved in politics?",
                "answer": "Getting involved in politics can start at various levels, such as local community engagement, joining political organizations, or participating in grassroots movements. Many politicians begin their careers by working on campaigns or holding local offices."
            }
        ]
    },

    "psychology": {
        "title": "Psychology FAQs",
        "content": "Here are some of the frequently asked questions","questions": [
            {
                "question": "What does a Psychologist do?",
                "answer": "Psychologists study and understand human behavior, providing therapy and counseling. They may specialize in clinical, counseling, or research psychology. Psychologists assess and treat mental health issues, conduct research studies, and contribute to the understanding of human behavior."
            },
            {
                "question": "What qualifications are required to become a Psychologist?",
                "answer": "To become a Psychologist, one typically needs at least a Master's degree in Psychology for counseling roles, and a Ph.D. or Psy.D. for clinical or research roles. Licensing or certification requirements may also apply depending on the specialization and jurisdiction."
            },
            {
                "question": "How important are communication skills in psychology?",
                "answer": "Communication skills are essential in psychology. Psychologists need to communicate effectively with clients, colleagues, and other professionals. Active listening, empathy, and clear communication contribute to building strong therapeutic relationships and conducting research effectively."
            }
        ]
    }
                    
        };

        function showFAQsForStream(stream) {
    var faqSection = document.getElementById('tes5');
    var faqContent = document.getElementById('tes2');
    var title = document.getElementById('title');

    // Assuming jsonData has properties for each stream like 'engineering', 'doctor', etc.
    var streamData = jsonData[stream];
    
    // Check if the specified stream exists in jsonData
    if (streamData) {
        title.innerText = streamData.title;
        faqContent.innerHTML = `<div class='tes3'>
                <div class='tes4'><span id="title">FAQs</span></div>
                <img src="sign-times-svgrepo-com.svg" class='x-sign'
                    onclick="hideFAQs()" title="Close" /></div><div class="faq-content">${streamData.content}</div><hr class='create-line-break'><ul style="background-color:white;">`;

        streamData.questions.forEach(function (qna, index) {
            faqContent.innerHTML += `
                <li style="font-family: Ebrima, Times, serif;">
                    <strong>${qna.question}</strong>
                    <p>${qna.answer}</p>
                </li>
            `;
        });

        faqContent.innerHTML += `</ul>`;
        faqSection.style.display = 'flex';
        // Add logic to hide overflow for a specific element if needed
        // const uyt = document.getElementById('op');
        // uyt.style.overflow = 'hidden';
    } else {
        console.error(`FAQs for the stream '${stream}' not found in jsonData.`);
    }
    const uyt = document.getElementById('op');
    uyt.style.overflow= 'hidden';
}
        function hideFAQs() {
            var faqSection = document.getElementById('tes5');
            faqSection.style.display = 'none';
            const uyt = document.getElementById('op');
    uyt.style.overflow= '';
        }

        document.addEventListener('click', function (event) {
    const result = document.getElementById('tes5');
    const tabl = document.getElementById('tes2');
    if (result.style.display === 'flex' && result.contains(event.target) && !tabl.contains(event.target)) {
      console.log('ut')
      hideFAQs();
    }
});
function googleTranslateElementInit() {
    new google.translate.TranslateElement({
      pageLanguage: 'fr',
      includedLanguages: 'en,hi',
        gaTrack: true,
        gaId: 'YOUR_GA_ID',  // Replace with your Google Analytics ID if you want to track translation usage
        autoDisplay: false
    }, 'google_translate_element');
  }
  // Get all div elements with the class "skiptranslate"
var skipTranslateDivs = document.querySelectorAll('div.skiptranslate');

// Loop through the selected divs and set display to none
skipTranslateDivs.forEach(function(div) {
  div.style.display = 'none';
});
function checkBodyTop() {
    var bodyTop = document.body.getBoundingClientRect().top;
  
    // Check if the body top is not 0px
    if (bodyTop !== 0) {
      // Set the body top to 0px
      document.body.style.top = '0px';
      
    }
  }
  
  // Call the function at regular intervals (every 100 milliseconds in this example)
  setInterval(checkBodyTop, 100);

  function hoverCard(isHovered,m) {
    var card = document.getElementById(m);
    var content = card.querySelector('.con');
    var meta = card.querySelector('.meta');
    
    if (isHovered) {
      content.style.transform = 'translateY(0)';
      meta.style.bottom = '55px';
    } else {
      content.style.transform = 'translateY(100%)';
      meta.style.bottom = '0px';
      con.style.backgroundColor = '#145889';
    }
  }
  